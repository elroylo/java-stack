package com.brendan.mybooks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
