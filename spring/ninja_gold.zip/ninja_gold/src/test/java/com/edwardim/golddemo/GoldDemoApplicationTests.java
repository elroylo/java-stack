package com.edwardim.golddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoldDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
