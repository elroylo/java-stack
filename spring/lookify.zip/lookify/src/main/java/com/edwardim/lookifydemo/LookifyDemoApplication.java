package com.edwardim.lookifydemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LookifyDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LookifyDemoApplication.class, args);
	}

}
