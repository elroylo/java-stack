package com.edwardim.lookifydemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LookifyDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
